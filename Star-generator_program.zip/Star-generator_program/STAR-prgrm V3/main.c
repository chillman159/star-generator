#include <stdio.h>
#include <stdlib.h>

int main()
{
     // Creation variables
     int choixEtoile, continuerPartie = 1;

    // Debut du Programme

    printf("===== STAR =====\n\n");


    // Boucle Display Star
    while (continuerPartie == 1 )
    {

        printf("Select the STAR size, between 1 and 5, in order to generate it :\n\n");
        scanf("%d", &choixEtoile);

        printf("\n\n");

        switch (choixEtoile)
        {
            case 1:
                printf("   *$\n*** ***$\n *   *$\n*** ***$\n   *$ ");
                printf("\n\nDo you want to display another star ?\n");
                printf("1. YES \n2. NO \n\n");
                scanf("%d", &continuerPartie);
                break;
            case 2:
                printf("      *\n     * *\n*****   *****\n *         *\n  *       *\n *         *\n*****   *****\n     * *\n      *");
                printf("\n\nDo you want to display another star ?\n");
                printf("1. YES \n2. NO \n\n");
                scanf("%d", &continuerPartie);
                break;
            case 3:
                printf("         *\n        * *\n       *   *\n*******     *******\n *               *\n  *             *\n   *           *\n  *             *\n *               *\n*******     *******\n       *   *\n        * *\n         *");
                printf("\n\nDo you want to display another star ?\n");
                printf("1. YES \n2. NO \n\n");
                scanf("%d", &continuerPartie);
                break;
            case 4:
                printf("            *\n           * *\n          *   *\n         *     *\n*********       *********\n *                     *\n  *                   *\n   *                 *\n    *               *\n   *                 *\n  *                   *\n *                     *\n*********       *********\n         *     *\n          *   *\n           * *\n            *");
                printf("\n\nDo you want to display another star ?\n");
                printf("1. YES \n2. NO \n\n");
                scanf("%d", &continuerPartie);
                break;
            case 5:
                printf("              *\n             * *\n            *   *\n           *     *\n          *       *\n***********       ***********\n *                         *\n  *                       *\n   *                     *\n    *                   *\n     *                 *\n    *                   *\n   *                     *\n  *                       *\n *                         *\n***********       ***********\n          *       *\n           *     *\n            *   *\n             * *\n              *");
                printf("\n\nDo you want to display another star ?\n");
                printf("1. YES \n2. NO \n\n");
                scanf("%d", &continuerPartie);
                break;
            default:
                printf("You didn't enter a correct star value... Try again\n");

                break;

        }

        // Fin programme
        if (continuerPartie != 1)
        {
            printf("\nThank you for using this program !\n");
        }

    }

  return 0;

}




